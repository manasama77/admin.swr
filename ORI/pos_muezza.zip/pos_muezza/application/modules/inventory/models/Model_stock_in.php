<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_stock_in extends CI_Model {
    
    public function __construct(){
		parent::__construct();
		$this->load->database();
    }

    function dd_branch()
    {
        $query = $this->db->query("SELECT branch_id, branch_code, branch_name FROM tblbranch");
        return $query;
    }
    
    function dd_branch_only($id)
    {
        $query = $this->db->query("SELECT * FROM tblbranch where branch_id='$id'");
        return $query;
    }
    
    function dd_supplier()
    {
        $query = $this->db->query("SELECT * FROM tblsupplier");
        return $query;
    }
    
    function dd_item()
    {
        $query = $this->db->query("SELECT * FROM tblitem order by item_name");
        return $query;
    }
    
	public function get_all(){
        $query = $this->db->query("SELECT *, CASE WHEN status = 0 THEN 'Draft' WHEN status = 1 THEN 'Final' END as strstatus 
        FROM tblstock_in a INNER JOIN tblbranch b ON a.branch_id=b.branch_id INNER JOIN tblsupplier c ON a.supplier_id=c.supplier_id");
        return $query;
	}
	
	public function get_by_id_master($id){
        $query = $this->db->query("SELECT * FROM tblstock_in WHERE stock_in_id='$id'");
        return $query->row();
    }
    
	public function get_by_id_detail($id){
        $query = $this->db->query("SELECT * FROM tblstock_in_det a INNER JOIN tblitem b ON a.item_id=b.item_id WHERE a.stock_in_id='$id'");
        return $query->result();
    }
    
	public function get_item($itemcode){
        $query = $this->db->query("SELECT * FROM tblitem WHERE item_code='$itemcode'");
        return $query->row();
    }
    
    public function save_data($branchid,$supplierid,$docnumber,$dtstockdate,$status,$description,$item,$creatorid){
        $stockinid = 0;

        $query = $this->db->query("insert into tblstock_in (branch_id,supplier_id,doc_number,stock_date,status,description,creator_id,created_date) 
        values('$branchid','$supplierid','$docnumber','$dtstockdate','$status','$description','$creatorid',NOW())");

        $stockinid = $this->db->insert_id();

        if($query){
            for ($i = 0; $i < sizeof($item['itemStockItem']); $i++) {
                $itemStockItem = $item['itemStockItem'][$i];
                $itemQty = $item['itemQty'][$i];
                $query = $this->db->query("insert into tblstock_in_det (stock_in_id,item_id,qty,creator_id,created_date) 
                values('$stockinid','$itemStockItem','$itemQty','$creatorid',now())");

                if($status == 1){
                    $query_exist = $this->db->query("select count(0) as is_exist from tblitem_stock where branch_id='$branchid' and item_id = '$itemStockItem'");
                    $data_exist = $query_exist->row_array();
                    $is_exist = $data_exist['is_exist'];
            
                    if($is_exist > 0){
                        $query = $this->db->query("update tblitem_stock set qty = qty + '$itemQty' where branch_id='$branchid' and item_id = '$itemStockItem'");
                    }
                    else{
                        $query = $this->db->query("insert into tblitem_stock(branch_id,item_id,qty) values('$branchid','$itemStockItem','$itemQty')");
                    }

                    $query_exist1 = $this->db->query("SELECT count(0) as is_exist FROM tblitem_price WHERE branch_id = '$branchid' AND item_id = '$itemStockItem' AND start_period<=DATE_FORMAT(NOW(),'%Y-%m-%d')");
                    $data_exist1 = $query_exist1->row_array();
                    $is_exist1 = $data_exist1['is_exist'];
            
                    $query_exist2 = $this->db->query("SELECT count(0) as is_exist FROM tblitem_price WHERE branch_id = '-1' AND item_id = '$itemStockItem' AND start_period<=DATE_FORMAT(NOW(),'%Y-%m-%d')");
                    $data_exist2 = $query_exist2->row_array();
                    $is_exist2 = $data_exist2['is_exist'];
                    
                    if($is_exist1 > 0){
                        $query = $this->db->query("SELECT buying_price FROM tblitem_price WHERE branch_id = '$branchid' AND item_id = '$itemStockItem' AND start_period<=DATE_FORMAT(NOW(),'%Y-%m-%d') ORDER BY start_period desc LIMIT 1");
                    }
                    else if($is_exist2 > 0){
                        $query = $this->db->query("SELECT buying_price FROM tblitem_price WHERE branch_id = '-1' AND item_id = '$itemStockItem' AND start_period<=DATE_FORMAT(NOW(),'%Y-%m-%d') ORDER BY start_period desc LIMIT 1");
                    }
                    else{
                        $query = $this->db->query("SELECT 0 as buying_price ");
                    }
                    $data = $query->row_array();
                    $itemBuyingPrice = $data['buying_price'];
                    
                    $query = $this->db->query("insert into tblstock_flow (branch_id,item_id,flow_type,flow_date,qty_trx,qty_now,price,information,reff_id,reff_trx) 
                    values('$branchid','$itemStockItem',1,NOW(),'$itemQty','$itemQty','$itemBuyingPrice','stock_in',null,'$docnumber')");
                }
            }
			return true;
		}else{
			return false;
		}
    }
	
    public function edit_data($branchid,$status,$description,$item,$modificatorid,$id){
        $query = $this->db->query("update tblstock_in set status = '$status',description = '$description', modificator_id='$modificatorid', modified_date=NOW() where stock_in_id = '$id'");
		if($query){
            $query = $this->db->query("delete from tblstock_in_det where stock_in_id ='$id'");
            for ($i = 0; $i < sizeof($item['itemStockItem']); $i++) {
                $itemStockItem = $item['itemStockItem'][$i];
                $itemQty = $item['itemQty'][$i];
                $query = $this->db->query("insert into tblstock_in_det (stock_in_id,item_id,qty,creator_id,created_date) 
                values('$id','$itemStockItem','$itemQty','$modificatorid',now())");
                
                if($status == 1){
                    $query_exist = $this->db->query("select count(0) as is_exist from tblitem_stock where branch_id='$branchid' and item_id = '$itemStockItem'");
                    $data_exist = $query_exist->row_array();
                    $is_exist = $data_exist['is_exist'];
            
                    if($is_exist > 0){
                        $query = $this->db->query("update tblitem_stock set qty = qty + '$itemQty' where branch_id='$branchid' and item_id = '$itemStockItem'");
                    }
                    else{
                        $query = $this->db->query("insert into tblitem_stock(branch_id,item_id,qty) values('$branchid','$itemStockItem','$itemQty')");
                    }

                    $query_exist1 = $this->db->query("SELECT count(0) as is_exist FROM tblitem_price WHERE branch_id = '$branchid' AND item_id = '$itemStockItem' AND start_period<=DATE_FORMAT(NOW(),'%Y-%m-%d')");
                    $data_exist1 = $query_exist1->row_array();
                    $is_exist1 = $data_exist1['is_exist'];
            
                    $query_exist2 = $this->db->query("SELECT count(0) as is_exist FROM tblitem_price WHERE branch_id = '-1' AND item_id = '$itemStockItem' AND start_period<=DATE_FORMAT(NOW(),'%Y-%m-%d')");
                    $data_exist2 = $query_exist2->row_array();
                    $is_exist2 = $data_exist2['is_exist'];
                    
                    if($is_exist1 > 0){
                        $query = $this->db->query("SELECT buying_price FROM tblitem_price WHERE branch_id = '$branchid' AND item_id = '$itemStockItem' AND start_period<=DATE_FORMAT(NOW(),'%Y-%m-%d') ORDER BY start_period desc LIMIT 1");
                    }
                    else if($is_exist2 > 0){
                        $query = $this->db->query("SELECT buying_price FROM tblitem_price WHERE branch_id = '-1' AND item_id = '$itemStockItem' AND start_period<=DATE_FORMAT(NOW(),'%Y-%m-%d') ORDER BY start_period desc LIMIT 1");
                    }
                    else{
                        $query = $this->db->query("SELECT 0 as buying_price ");
                    }
                    $data = $query->row_array();
                    $itemBuyingPrice = $data['buying_price'];
                    
                    $query = $this->db->query("insert into tblstock_flow (branch_id,item_id,flow_type,flow_date,qty_trx,qty_now,price,information,reff_id,reff_trx) 
                    values('$branchid','$itemStockItem',1,NOW(),'$itemQty','$itemQty','$itemBuyingPrice','stock_in',null,'$docnumber')");
                }
            }
			return true;
		}else{
			return false;
		}
    }
    
    public function delete($id){
        $query = $this->db->query("delete from tblstock_in where stock_in_id ='$id'");
        if($query){
            $query = $this->db->query("delete from tblstock_in_det where stock_in_id ='$id'");
            return true;
		}else{
			return false;
        }
    }
	
    public function check_docnumber_exist($docnumber){
        $query = $this->db->query("select count(0) as is_exist from tblstock_in where doc_number ='$docnumber'");
        return $query->row();
    }
}