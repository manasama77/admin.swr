<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_profit_report extends CI_Model {
    
    public function __construct(){
		parent::__construct();
		$this->load->database();
    }

    function dd_branch()
    {
        $query = $this->db->query("SELECT 0 as branch_id, 'Semua Cabang' as branch_code, '' as branch_name UNION ALL SELECT branch_id, branch_code, branch_name FROM tblbranch");
        return $query;
    }
    
    function dd_branch_only($id)
    {
        $query = $this->db->query("SELECT * FROM tblbranch where branch_id='$id'");
        return $query;
    }
    
    function dd_item()
    {
        $query = $this->db->query("SELECT * FROM tblitem");
        return $query;
    }
    
    function get_header($startperiod,$endperiod){
        $query = $this->db->query("SELECT '$startperiod' as startperiod, '$endperiod' as endperiod");
        return $query->row();
    }

	function get_report_array($startperiod,$endperiod,$branchid,$itemid){
        $whereall = "";
        
        if($branchid > 0){
            $whereall = $whereall . " AND a.branch_id = '$branchid'";
        }

        if($itemid > 0){
            $whereall = $whereall . " AND d.item_id = '$itemid' ";
        }

        $query = "SELECT * FROM ( "
                . "SELECT c.branch_code, c.branch_name, b.item_id, d.barcode, d.item_name, a.sales_number as trans_number, e.qty_now, (e.qty_now * e.buy_price) as tot_hpp, (e.qty_now * e.sell_price) as tot_sell_price, ((e.sell_price - e.buy_price) * e.qty_now) as profit, a.created_date "
                . "FROM tblsales a inner join tblsales_det b on a.sales_id=b.sales_id "
                . "inner join tblbranch c on a.branch_id=c.branch_id "
                . "inner join tblitem d on b.item_id=d.item_id "
                . "inner join ( "
                    . "select a.branch_id, a.item_id, a.qty_now, b.price as buy_price, a.price as sell_price, a.reff_trx "
                    . "from tblstock_flow a left join tblstock_flow b on a.reff_id=b.stock_flow_id "
                    . "where a.flow_type=2 and a.flow_date>='$startperiod' AND DATE_FORMAT(a.flow_date,'%Y-%m-%d')<='$endperiod' and left(a.reff_trx,3)='POS' "
                . ") e on a.sales_number=e.reff_trx and b.item_id=e.item_id "
                . "where a.created_date>='$startperiod' AND DATE_FORMAT(a.created_date,'%Y-%m-%d')<='$endperiod' " . $whereall
                . "UNION ALL "
                . "SELECT c.branch_code, c.branch_name, b.item_exchange, d.barcode, d.item_name, a.sales_exchange_number as trans_number, e.qty_now, (e.qty_now * e.buy_price) as tot_hpp, (e.qty_now * e.sell_price) as tot_sell_price, ((e.sell_price - e.buy_price) * e.qty_now) as profit, a.created_date "
                . "FROM tblsales_exchange a inner join tblsales_exchange_det b on a.sales_exchange_id=b.sales_exchange_id "
                . "inner join tblbranch c on a.branch_id=c.branch_id "
                . "inner join tblitem d on b.item_exchange=d.item_id "
                . "inner join ( "
                    . "select a.branch_id, a.item_id, a.qty_now, b.price as buy_price, c.sell_price, a.reff_trx "
                    . "from tblstock_flow a left join tblstock_flow b on a.reff_id=b.stock_flow_id "
                    . "left join (select reff_trx, sum(price) as sell_price from tblstock_flow where flow_date>='$startperiod' AND DATE_FORMAT(flow_date,'%Y-%m-%d')<='$endperiod' group by reff_trx) c on a.reff_trx=c.reff_trx "
                    . "where a.flow_type=2 and a.flow_date>='$startperiod' AND DATE_FORMAT(a.flow_date,'%Y-%m-%d')<='$endperiod' and left(a.reff_trx,3)='EXC' "
                . ") e on a.sales_exchange_number=left(e.reff_trx,13) and b.item_exchange=e.item_id "
                . "where a.created_date>='$startperiod' AND DATE_FORMAT(a.created_date,'%Y-%m-%d')<='$endperiod' " . $whereall
                . ") a order by branch_code, created_date ";
        $data = $this->db->query($query);
        return $data->result_array();
    }
    
	function get_report($startperiod,$endperiod,$branchid,$itemid){
        $whereall = "";
        
        if($branchid > 0){
            $whereall = $whereall . " AND a.branch_id = '$branchid'";
        }

        if($itemid > 0){
            $whereall = $whereall . " AND b.item_id = '$itemid' ";
        }

        $query = "SELECT c.branch_code, c.branch_name, d.barcode, d.item_name, e.qty_now, (e.qty_now * e.buy_price) as tot_hpp, (e.qty_now * e.sell_price) as tot_sell_price, ((e.sell_price - e.buy_price) * e.qty_now) as profit "
                . "FROM tblsales a inner join tblsales_det b on a.sales_id=b.sales_id "
                . "inner join tblbranch c on a.branch_id=c.branch_id "
                . "inner join tblitem d on b.item_id=d.item_id "
                . "inner join ( "
                    . "select a.branch_id, a.item_id, a.flow_date, a.qty_now, b.price as buy_price, a.price as sell_price, a.reff_trx "
                    . "from tblstock_flow a left join tblstock_flow b on a.reff_id=b.stock_flow_id "
                    . "where a.flow_type=2 and a.flow_date>='$startperiod' AND DATE_FORMAT(a.flow_date,'%Y-%m-%d')<='$endperiod' and left(a.reff_trx,3)='POS' "
                . ") e on a.sales_number=e.reff_trx and b.item_id=e.item_id "
                . "where a.created_date>='$startperiod' AND DATE_FORMAT(a.created_date,'%Y-%m-%d')<='$endperiod' " . $whereall
                . "order by a.branch_id, b.item_id ";
        $data = $this->db->query($query);
        return $data;
    }
}