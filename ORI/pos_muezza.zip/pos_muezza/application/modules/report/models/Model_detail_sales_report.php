<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_detail_sales_report extends CI_Model {
    
    public function __construct(){
		parent::__construct();
		$this->load->database();
    }

    function dd_user()
    {
        $query = $this->db->query("SELECT * FROM tbluser a INNER JOIN tbluser_group b ON a.user_group_id=b.user_group_id WHERE b.is_cashier=1");
        return $query;
    }
    
    function dd_branch()
    {
        $query = $this->db->query("SELECT 0 as branch_id, 'Semua Cabang' as branch_code, '' as branch_name UNION ALL SELECT branch_id, branch_code, branch_name FROM tblbranch");
        return $query;
    }
    
    function dd_branch_only($id)
    {
        $query = $this->db->query("SELECT * FROM tblbranch where branch_id='$id'");
        return $query;
    }
    
    function get_header($startperiod,$endperiod){
        $query = $this->db->query("SELECT '$startperiod' as startperiod, '$endperiod' as endperiod");
        return $query->row();
    }

	function get_report_array($startperiod,$endperiod,$userid,$branchid){
        $whereall = "";
        if($userid > 0){
            $whereall = $whereall . " AND a.creator_id = '$userid'";
        }
        
        if($branchid > 0){
            $whereall = $whereall . " AND a.branch_id = '$branchid'";
        }

        $query = "SELECT d.fullname as cashier_name, e.branch_code, e.branch_name, a.sales_number, a.created_date as sales_date, "
                . "c.barcode, c.item_name, b.price, b.disc, b.extra_disc, b.qty, b.subtotal, a.total_price, a.total_disc, a.total_transaction "
                . "FROM tblsales a LEFT JOIN tblsales_det b ON a.sales_id = b.sales_id "
                . "LEFT JOIN tblitem c ON b.item_id = c.item_id "
                . "LEFT JOIN tbluser d ON a.creator_id = d.user_id "
                . "LEFT JOIN tblbranch e ON a.branch_id = e.branch_id "
                . "WHERE a.created_date>='$startperiod' AND DATE_FORMAT(a.created_date,'%Y-%m-%d')<='$endperiod' " . $whereall
                . "ORDER BY a.sales_number, b.sales_det_id";
        $data = $this->db->query($query);
        return $data->result_array();
    }
    
	function get_report($startperiod,$endperiod,$userid,$branchid){
        $whereall = "";
        if($userid > 0){
            $whereall = $whereall . " AND a.creator_id = '$userid'";
        }
        
        if($branchid > 0){
            $whereall = $whereall . " AND a.branch_id = '$branchid'";
        }

        $query = "SELECT d.fullname as cashier_name, e.branch_code, e.branch_name, a.sales_number, a.created_date as sales_date, "
                . "c.barcode, c.item_name, b.price, b.disc, b.extra_disc, b.qty, b.subtotal, a.total_price, a.total_disc, a.total_transaction "
                . "FROM tblsales a LEFT JOIN tblsales_det b ON a.sales_id = b.sales_id "
                . "LEFT JOIN tblitem c ON b.item_id = c.item_id "
                . "LEFT JOIN tbluser d ON a.creator_id = d.user_id "
                . "LEFT JOIN tblbranch e ON a.branch_id = e.branch_id "
                . "WHERE a.created_date>='$startperiod' AND DATE_FORMAT(a.created_date,'%Y-%m-%d')<='$endperiod' " . $whereall
                . "ORDER BY a.sales_number, b.sales_det_id";
        $data = $this->db->query($query);
        return $data;
    }
}