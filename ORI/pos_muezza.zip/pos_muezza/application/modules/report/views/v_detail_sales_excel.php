<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>POS Apps</title>
        <link href="<?php echo base_url('assets/adminlte/bower_components/bootstrap/dist/css/bootstrap.min.css') ?>" rel="stylesheet" type="text/css" />
    </head>
    <body>
        <?php 
            header("Content-type: application/vnd-ms-excel");
            header("Content-Disposition: attachment; filename=DetailPenjualan.xls");

            $table = '<table>
                    <tr>
                        <th colspan="7" style="text-align:center;">Detail Penjualan</td>
                    </tr>
                    <tr>
                        <th colspan="7" style="text-align:center;">Periode : ' . $header->startperiod . ' - ' . $header->endperiod . '</td>
                    </tr>
                    <tr>
                        <td colspan="7" style="text-align:center;">&nbsp;</td>
                    </tr>
                    <thead>
                        <tr>
                            <th style="width:5%; text-align:center;">No</th>
                            <th style="width:55%; text-align:center;">Barang</th>
                            <th style="width:10%; text-align:center;">Harga</th>
                            <th style="width:10%; text-align:center;">Diskon</th>
                            <th style="width:10%; text-align:center;">Jumlah</th>
                            <th style="width:10%; text-align:center;">Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>';

            $i = 1;

            $salesnumberold = 'xx';
            $salesnumbernew = '';
            
            $totalprice = "";
            $totaldisc = "";
            $totaltransaction = "";

            foreach($report->result() as $row) :

                $salesnumbernew = $row->sales_number;

                if($salesnumberold != $salesnumbernew){
                    $i = 1;
                    
                    if($salesnumberold != 'xx'){

                        $table .= '<tr>
                                <td style="text-align:right;" colspan="6"><strong>Total Transaksi : </strong></td><td style="text-align:right;">' . $totalprice . '</td>
                                </tr>
                                <tr>
                                <td style="text-align:right;" colspan="6"><strong>Total Disc : </strong></td><td style="text-align:right;">' . $totaldisc . '</td>
                                </tr>
                                <tr>
                                <td style="text-align:right;" colspan="6"><strong>Total Penjualan : </strong></td><td style="text-align:right;">' . $totaltransaction . '</td>
                                </tr>';

                    }
                    
                    $table .= '<tr>
                        <td style="text-align:left;" colspan="7"><strong>Tanggal Penjualan : ' . $row->sales_date . ' / Nomor Penjualan : ' . $row->sales_number . ' / Cabang : (' . $row->branch_code . ') ' . $row->branch_name . ' / Kasir : ' . $row->cashier_name . '</strong></td>
                        </tr>';
                }
                
                $table .= '<tr>
                    <td style="text-align:center;">' . $i . '</td>
                    <td style="text-align:left;">(' . $row->barcode . ') ' . $row->item_name . '</td>
                    <td style="text-align:right;">' . $row->price . '</td>
                    <td style="text-align:right;">' . $row->extra_disc . '</td>
                    <td style="text-align:center;">' . $row->qty . '</td>
                    <td style="text-align:right;">' . $row->subtotal . '</td>
                </tr>';

                $i = $i + 1;
                $salesnumberold = $salesnumbernew;

            endforeach;

            $table .= '<tr>
                    <td style="text-align:right;" colspan="6"><strong>Total Transaksi : </strong></td><td style="text-align:right;">' . $row->total_price . '</td>
                    </tr>
                    <tr>
                    <td style="text-align:right;" colspan="6"><strong>Total Disc : </strong></td><td style="text-align:right;">' . $row->total_disc . '</td>
                    </tr>
                    <tr>
                    <td style="text-align:right;" colspan="6"><strong>Total Penjualan : </strong></td><td style="text-align:right;">' . $row->total_transaction . '</td>
                    </tr>';

            echo $table;

        ?>
    </body>
</html>