<?php 
$this->load->view('template/header');
?>
<!--tambahkan custom css disini-->
<?php
$this->load->view('template/topbar');
$this->load->view('template/sidebar');
?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">

<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>
        Barang
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Data Utama</a></li>
        <li class="active">Barang</li>
    </ol>
</section>

<section class="content">
    <div class="box box-info">
        <div class="box-header with-border">
            <button onclick="add_data()" class="btn btn-primary bold"><i class="fa fa-plus-circle"></i> Tambah Data</button>
        </div>
        <div class="box-body">
            <table id="StockTable" class="table table-bordered table-striped" style="width:100%">
                <thead>
                    <tr>
                        <th>Kategori Barang</th>
                        <th>Satuan Barang</th>
                        <th>Kode Barang</th>
                        <th>Nama Barang</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($stockitem->result() as $row) :?>
                        <tr>
                            <td><?php echo $row->stock_category_name; ?></td>
                            <td><?php echo $row->unit_name; ?></td>
                            <td><?php echo $row->item_code; ?></td>
                            <td><?php echo $row->item_name; ?></td>
                            <td>
                                <button class="btn btn-sm btn-success bold" onclick="view_data(<?php echo $row->item_id; ?>)"><i class="fa fa-file-text-o"></i></button>
                                    &nbsp;
                                <button class="btn btn-sm btn-warning bold" onclick="edit_data(<?php echo $row->item_id; ?>)"><i class="fa fa-pencil"></i></button>
                                    &nbsp;
                                <button class="btn btn-sm btn-danger bold" onclick="delete_data(<?php echo $row->item_id; ?>)"><i class="fa fa-ban"></i></button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</section>

<div class="modal fade bd-example-modal-lg" id="FormModal">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" style="text-align:center;"><strong>Role Form</strong></h4>
            </div>
            <form action="#" id="form" class="form-horizontal">
                <div class="modal-body">
                    <input type="hidden" class="form-control" id="formtype" name="formtype" value="">
                    <input type="hidden" class="form-control" id="itemid" name="itemid" value="0">

                    <input type="hidden" class="form-control" id="isfotofilename" name="isfotofilename" value="0">
                    <input type="hidden" class="form-control" id="strfotofilename" name="strfotofilename" value="">
                    <input type="hidden" class="form-control" id="strfotopreview" name="strfotopreview" value="">

                    <div class="form-group">
                        <label class="col-sm-4 control-label">Kode Barang</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" id="itemcode" name="itemcode">
                        </div>
                    </div>
                    <!--div class="form-group">
                        <label class="col-sm-4 control-label">Barcode</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" id="barcode" name="barcode">
                        </div>
                    </div-->
                    <div class="form-group">
                        <label class="col-sm-4 control-label">Kategori Barang</label>
                        <div class="col-sm-6">
                        <select class="form-control select2" id="stockcategoryid" name="stockcategoryid" style="width: 100%;">
                            <option value='0' selected>Silahkan Pilih</option>
                            <?php foreach($stockcategory->result() as $row) :?>
                            <?php echo "<option value='" . $row->stock_category_id . "'>(" . $row->stock_category_code . ") " . $row->stock_category_name . "</option>"; ?>
                            <?php endforeach; ?>
                        </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-4 control-label">Satuan Barang</label>
                        <div class="col-sm-6">
                        <select class="form-control select2" id="unitid" name="unitid" style="width: 100%;">
                            <option value='0' selected>Silahkan Pilih</option>
                            <?php foreach($unit->result() as $row) :?>
                            <?php echo "<option value='" . $row->unit_id . "'>(" . $row->unit_code . ") " . $row->unit_name . "</option>"; ?>
                            <?php endforeach; ?>
                        </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-4 control-label">Nama Barang</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" id="itemname" name="itemname">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-4 control-label">Gambar Barang</label>
                        <div class="col-sm-6">
                            <input id="foto" name="foto" type="file">
                            <br/>* Gambar dengan format .jpg / .jpeg / .png
                            <br/><div id="fotopreview"></div>
                        </div>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-success pull-left" data-dismiss="modal">Batal</button>
                    <button type="button" id="btnSave" onclick="save_data()" class="btn btn-danger pull-right">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="ImportModal">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" style="text-align:center;"><strong>Import Data</strong></h4>
            </div>
            <form class="form-horizontal" method='post' action='' enctype="multipart/form-data" id="formimport">
                <div class="modal-body">
                    <div class="form-group">
                        <label class="col-sm-4 control-label">Excel File</label>
                        <div class="col-sm-6">
                            <input type="file" name="file">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-4 control-label"></label>
                        <div class="col-sm-6">
                            <font color="red">* Only .xls excel file accepted</font>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-success pull-left" data-dismiss="modal">Cancel</button>
                    <button type="submit" id="btnImport" class="btn btn-danger pull-right">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="WarningModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h3 class="modal-title" style="text-align:center;"><strong>Notification</strong></h3>
			</div>
			<div class="modal-body">
				<div id="WarningContent"></div>
			</div>
			<div class="modal-footer">
				<button type="button" id="btnClose" class="btn btn-success pull-right" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>

<div class="modal fade" id="ConfirmModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h3 class="modal-title" style="text-align:center;"><strong>Warning</strong></h3>
			</div>
			<div class="modal-body">
				<input type="hidden" class="form-control" id="dataId" name="dataId" value="0">
				<div id="ConfirmContent"></div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-success pull-left" data-dismiss="modal">No</button>
				<button type="button" id="btnConfirm" class="btn btn-danger pull-right">Yes</button>
			</div>
		</div>
	</div>
</div>

</div>

<?php 
$this->load->view('template/js');
?>
<script>
    $(".select2").select2();

    $("#StockTable").DataTable({
        dom: 'Bfrtip',
        lengthMenu: [
            [10, 25, 50, -1],
            ['10 rows', '25 rows', '50 rows', 'Show all']
        ],
        buttons: [
            'pageLength',
            {
                extend: 'excelHtml5',
                title: 'Satuan Barang',
                exportOptions: {
                    columns: [0, 1, 2, 3]
                }
            },
            {
                extend: 'pdfHtml5',
                title: 'Satuan Barang',
                orientation: 'portrait',
                pageSize: 'A4',
                exportOptions: {
                    columns: [0, 1, 2, 3]
                },
                customize: function (doc) {
                    doc.content[1].table.widths = 
                        Array(doc.content[1].table.body[0].length + 1).join('*').split('');
                }
            }, 'print'
        ],
        "scrollX": true,
        "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
        'searching': true,
        'ordering': true
    });

	$('#ImportButton').click(function (e) {
		$('#ImportModal').modal('show');
	});
	
    $(document).ready(function(){
        $('#ExportButton').click(function (e) {
            get_export();
        });

        $('#formimport').submit(function(e){
			$('#ImportModal').modal('hide');
			
			e.preventDefault(); 
			
			var filename = $('input[type=file]').val().replace(/.*(\/|\\)/, '');
			var extension = filename.replace(/^.*\./, '');
			if (extension == filename) {
				extension = '';
			} else {
				extension = extension.toLowerCase();
			}

			if(extension == "xls"){
				$.ajax({
					url:'<?php echo site_url() ?>master/stock_item/file_upload',
					type:"post",
					data:new FormData(this),
					processData:false,
					contentType:false,
					cache:false,
					async:false,
					success: function(data){
						window.location.href = '<?php echo site_url() ?>master/stock_item/import/'+filename;
					}
				});
			}
			else{
				$("#WarningContent").replaceWith("<div id='WarningContent'>Only accept .xls excel file</div>");
				$('#WarningModal').modal('show');
			}
        });

        $("#foto").change(function () {
            $('#isfotofilename').val(1);
        });
    });

    function get_export(){
        var win = window.open('<?php echo site_url() ?>master/stock_item/get_export', '_blank');
        if (win) {
            win.focus();
        } else {
            $("#WarningContent").replaceWith("<div id='WarningContent'>Please allow popups for this website</div>");
			$('#WarningModal').modal('show');
        }
    }
    
    function val_delete(id){
		$('#dataId').val(id);
		$("#ConfirmContent").replaceWith("<div id='ConfirmContent'>Are you sure delete this data?</div>");
        $('#ConfirmModal').modal('show');
    }
	
	$(function () {
		$('#btnConfirm').click(function (e) {
            var dataId = $('#dataId').val();
			$('#ConfirmModal').modal('hide');
            
			var success = true;
            $.ajax({
                type     : 'POST',
                dataType : 'JSON',
                url      : '<?php echo site_url() ?>master/stock_item/delete',
                data     :{
                    itemid : dataId
                },
                success: function(data){
					$("#WarningContent").replaceWith("<div id='WarningContent'>" + data + "</div>");
                },
				error:  function(){
					success=false;
				}
            });
			
			if(success){
				$('#WarningModal').modal('show');
			}
        });
		
		$('#btnClose').click(function (e) {
			$('#WarningModal').modal('hide');
			location.reload();
		});
	});

    function add_data()
    {
        $('#formtype').val("add");
        $('#form')[0].reset(); // reset form on modals

        $('#supplierid').val(0).change();
        $('#stockcategoryid').val(0).change();
        $('#unitid').val(0).change();

        $('#supplierid').attr('disabled',false); //set button disable 
        $('#stockcategoryid').attr('disabled',false); //set button disable 
        $('#unitid').attr('disabled',false); //set button disable 
        $('#itemnama').attr('disabled',false); //set button disable 
        //$('#barcode').attr('disabled',false); //set button disable 
        //$('#minimumstock').attr('disabled',false); //set button disable 
        //$('#maximumstock').attr('disabled',false); //set button disable 

        $('#fotopreview').html('');
/*
        var result           = '';
        var characters       = '0123456789';
        var charactersLength = characters.length;
        for ( var i = 0; i < 12; i++ ) {
            result += characters.charAt(Math.floor(Math.random() * charactersLength));
        }
        $('#barcode').val(result);
*/
        $('#FormModal').modal('show'); // show bootstrap modal
        $('.modal-title').text('Tambah Data Barang'); // Set Title to Bootstrap modal title
    }

    function view_data(itemid)
    {
        $('#formtype').val("edit");

        //Ajax Load data from ajax
        $.ajax({
            type    : "POST",
            dataType: "JSON",
            url     : "<?php echo site_url() ?>master/stock_item/ajax_view",
            data    : {
                    id: itemid
                },
            success: function(data)
            {
                $('#itemid').val(itemid);
                $('#supplierid').val(data.supplier_id).change();
                $('#stockcategoryid').val(data.stock_category_id).change();
                $('#unitid').val(data.unit_id).change();
                $('#itemcode').val(data.item_code);
                $('#itemname').val(data.item_name);
                //$('#barcode').val(data.barcode);
                //$('#minimumstock').val(data.minimum_stock);
                //$('#maximumstock').val(data.maximum_stock);
                $('#fotopreview').html(data.foto_preview);

                var fotofilename = data.foto_filename;
                var fotopreview = data.foto_preview;
                if(fotofilename.length > 0){
                    $('#isfotofilename').val(0);
                    $('#strfotofilename').val(fotofilename);
                    $('#strfotopreview').val(fotopreview);
                }

                $('#supplierid').attr('disabled',true); //set button disable 
                $('#stockcategoryid').attr('disabled',true); //set button disable 
                $('#unitid').attr('disabled',true); //set button disable 
                $('#itemname').attr('disabled',true); //set button disable 
                //$('#barcode').attr('disabled',true); //set button disable 
                //$('#minimumstock').attr('disabled',true); //set button disable 
                //$('#maximumstock').attr('disabled',true); //set button disable 

                $('#FormModal').modal('show'); // show bootstrap modal
                $('.modal-title').text('Lihat Data Barang'); // Set Title to Bootstrap modal title
            },
            error: function ()
            {
                alert('Failed Lookup Data');
            }
        });
    }

    function edit_data(itemid)
    {
        $('#formtype').val("edit");

        //Ajax Load data from ajax
        $.ajax({
            type    : "POST",
            dataType: "JSON",
            url     : "<?php echo site_url() ?>master/stock_item/ajax_view",
            data    : {
                    id: itemid
                },
            success: function(data)
            {
                $('#itemid').val(itemid);
                $('#supplierid').val(data.supplier_id).change();
                $('#stockcategoryid').val(data.stock_category_id).change();
                $('#unitid').val(data.unit_id).change();
                $('#itemcode').val(data.item_code);
                $('#itemname').val(data.item_name);
                //$('#barcode').val(data.barcode);
                //$('#minimumstock').val(data.minimum_stock);
                //$('#maximumstock').val(data.maximum_stock);
                $('#fotopreview').html(data.foto_preview);

                var fotofilename = data.foto_filename;
                var fotopreview = data.foto_preview;
                if(fotofilename.length > 0){
                    $('#isfotofilename').val(0);
                    $('#strfotofilename').val(fotofilename);
                    $('#strfotopreview').val(fotopreview);
                }

                $('#supplierid').attr('disabled',false); //set button disable 
                $('#stockcategoryid').attr('disabled',false); //set button disable 
                $('#unitid').attr('disabled',false); //set button disable 
                $('#itemname').attr('disabled',false); //set button disable 
                //$('#barcode').attr('disabled',false); //set button disable 
                //$('#minimumstock').attr('disabled',false); //set button disable 
                //$('#maximumstock').attr('disabled',false); //set button disable 

                $('#FormModal').modal('show'); // show bootstrap modal
                $('.modal-title').text('Ubah Data Barang'); // Set Title to Bootstrap modal title
            },
            error: function ()
            {
                alert('Failed Lookup Data');
            }
        });
    }

    function save_data()
    {
        var isfotofilename = $('#isfotofilename').val();
        var strfotopreview = $('#strfotopreview').val();
        
        var filename1 = $('#foto').val().replace(/.*(\/|\\)/, '');
        var extension1 = filename1.replace(/^.*\./, '');
        if (extension1 == filename1) {
            extension1 = '';
        } else {
            extension1 = extension1.toLowerCase();
        }

        var isvalid = false;
        if((isfotofilename == 1) && ((extension1 == "jpg") || (extension1 == "jpeg") || (extension1 == "png"))){
            isvalid = true;
        }
        else if(isfotofilename == 0){
            isvalid = true;
        }

        if(!isvalid){
            swal({
                title: "Notifikasi",
                text: "Foto yang diupload tidak menggunakan format yang diharuskan",
                type: "warning"
            });
        }
        else{
            $('#btnSave').text('saving...'); //change button text
            $('#btnSave').attr('disabled',true); //set button disable 
            var url;
            var formtype = $('#formtype').val();

            if(formtype == 'add') {
                url = "<?php echo site_url() ?>master/stock_item/ajax_add";
            } else {
                url = "<?php echo site_url() ?>master/stock_item/ajax_update";
            }
        
            $('#formtype').val("");
            var frm = $('#form');
            // ajax adding data to database
            var frmData = new FormData(frm[0]);
            $.ajax({
                url : url,
                type: "POST",
                data: frmData,
                contentType: false,
                processData: false,
                dataType: "JSON",
                success: function(data)
                {
                    if(data.status) //if success close modal and reload ajax table
                    {
                        swal({
                            title: "Notifikasi",
                            text: data.message,
                            type: "success"
                        }, 
                        function() {
                            location.reload();
                        }
                    );
                    }
                    else{
                        swal({
                            title: "Notifikasi",
                            text: data.message,
                            type: "warning"
                        });
                    }
                },
                error: function (jqXHR, textStatus, errorThrown)
                {
                    $('#btnSave').text('save'); 
                    $('#btnSave').attr('disabled',false); 
                    swal({
                        title: "Peringatan",
                        text: "Gagal Memproses Data",
                        type: "warning"
                    });
                }
            });
        }
    }

    function delete_data(itemid)
    {
        swal({
                title: "Hapus Data",
                text: "Apa anda yakin menghapus data ini?",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: "Hapus",
                cancelButtonText: "Batal",
                closeOnConfirm: false,
                closeOnCancel: false 
            },
            function (isConfirm) {
                if (isConfirm) {
                    // ajax delete data to database
                    $.ajax({
                        type    : "POST",
                        dataType: "JSON",
                        url     : "<?php echo site_url() ?>master/stock_item/ajax_delete",
                        data    : {
                            id: itemid
                        },
                        success: function(data)
                        {
                            swal({
                                    title: "Notifikasi",
                                    text: data.message,
                                    type: "success"
                                }, 
                                function() {
                                    location.reload();
                                }
                            );
                        },
                        error: function (jqXHR, textStatus, errorThrown)
                        {
                            swal({
                                title: "Peringatan",
                                text: "Gagal Memproses Data",
                                type: "warning"
                            });
                        }
                    });
                } else {
                    swal("Batal", "Data tidak jadi dihapus", "error");
                }
            }
        );
    }
    
</script>
<?php
$this->load->view('template/footer');
?>
